<script>
   var res = "success";
</script>
<?php
   $a="<script>document.writeln(res);</script>";
   echo $a;
?>