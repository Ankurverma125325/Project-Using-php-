<?php
session_start();
$a=$_SESSION["name"];
echo $a;
?>